
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Detection } from '../types';
import { BoundingBox } from './BoundingBox';

interface WebcamFeedProps {
  onFrame: (base64Image: string) => void;
  detections: Detection[];
  isDetecting: boolean;
}

export const WebcamFeed: React.FC<WebcamFeedProps> = ({ onFrame, detections, isDetecting }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [videoDimensions, setVideoDimensions] = useState({ width: 0, height: 0 });
  const [error, setError] = useState<string | null>(null);

  const setupWebcam = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user' 
        } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          if (videoRef.current) {
             setVideoDimensions({
              width: videoRef.current.videoWidth,
              height: videoRef.current.videoHeight,
            });
          }
        };
      }
    } catch (err) {
      console.error("Error accessing webcam:", err);
      setError("Could not access webcam. Please grant permission and try again.");
    }
  }, []);

  useEffect(() => {
    setupWebcam();
  }, [setupWebcam]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (videoRef.current && canvasRef.current && !isDetecting) {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        if (video.readyState >= 3) { // HAVE_FUTURE_DATA
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            if(context) {
                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
                onFrame(dataUrl);
            }
        }
      }
    }, 2000); // Process a frame every 2 seconds

    return () => clearInterval(interval);
  }, [onFrame, isDetecting]);

  const handleResize = useCallback(() => {
    if (videoRef.current) {
      setVideoDimensions({
        width: videoRef.current.clientWidth,
        height: videoRef.current.clientHeight,
      });
    }
  }, []);

  useEffect(() => {
    window.addEventListener('resize', handleResize);
    // Initial size set
    const timer = setTimeout(handleResize, 100);
    return () => {
        window.removeEventListener('resize', handleResize);
        clearTimeout(timer);
    }
  }, [handleResize]);


  return (
    <div className="relative w-full aspect-video bg-gray-950 rounded-lg shadow-2xl overflow-hidden border-2 border-gray-700 flex items-center justify-center">
      {error && <p className="text-red-400 p-4">{error}</p>}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className={`w-full h-full object-cover transition-opacity duration-300 ${videoDimensions.width > 0 ? 'opacity-100' : 'opacity-0'}`}
        onCanPlay={handleResize}
      />
      <canvas ref={canvasRef} className="hidden" />
      
      {detections.map((detection, index) => (
        <BoundingBox
          key={index}
          box={detection.box}
          label={detection.label}
          gender={detection.gender}
          containerWidth={videoDimensions.width}
          containerHeight={videoDimensions.height}
        />
      ))}
      
      {isDetecting && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-teal-400"></div>
        </div>
      )}
    </div>
  );
};
