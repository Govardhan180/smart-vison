
import React from 'react';
import { BoundingBox as BoundingBoxType } from '../types';

interface BoundingBoxProps {
  box: BoundingBoxType;
  label: string;
  gender?: 'Male' | 'Female' | 'Unknown';
  containerWidth: number;
  containerHeight: number;
}

export const BoundingBox: React.FC<BoundingBoxProps> = ({ box, label, gender, containerWidth, containerHeight }) => {
  if (containerWidth === 0 || containerHeight === 0) {
    return null;
  }

  const x = box.x * containerWidth;
  const y = box.y * containerHeight;
  const width = box.width * containerWidth;
  const height = box.height * containerHeight;

  const color = label === 'Person' ? 'border-teal-400' : 'border-amber-400';
  const bgColor = label === 'Person' ? 'bg-teal-400/80' : 'bg-amber-400/80';
  
  const displayText = label === 'Person' ? gender || label : label;

  return (
    <div
      className={`absolute ${color} border-2 rounded-md shadow-lg transition-all duration-300`}
      style={{
        left: `${x}px`,
        top: `${y}px`,
        width: `${width}px`,
        height: `${height}px`,
      }}
    >
      <span
        className={`absolute -top-7 left-0 ${bgColor} text-gray-900 text-xs font-semibold px-2 py-1 rounded-md whitespace-nowrap`}
      >
        {displayText}
      </span>
    </div>
  );
};
