
import React from 'react';
import { Detection } from '../types';

interface DetectionResultsProps {
  detections: Detection[];
  isDetecting: boolean;
  error: string | null;
}

const Icon = ({ name }: { name: string }) => {
    const icons: { [key: string]: string } = {
        Person: '👤',
        Male: '👨',
        Female: '👩',
        Unknown: '❓',
        default: '👁️',
    };
    return <span className="mr-3 text-xl">{icons[name] || icons.default}</span>;
};

export const DetectionResults: React.FC<DetectionResultsProps> = ({ detections, isDetecting, error }) => {
    const detectedPersons = detections.filter(d => d.label === 'Person');
    const detectedObjects = detections.filter(d => d.label !== 'Person');
    
  return (
    <div className="flex flex-col h-full">
      <h2 className="text-2xl font-bold text-teal-400 mb-4 border-b-2 border-teal-400/30 pb-2">Detection Analysis</h2>
      
      {error && (
        <div className="bg-red-900/50 border border-red-700 text-red-300 p-4 rounded-lg">
          <p className="font-bold">Error</p>
          <p>{error}</p>
        </div>
      )}
      
      {!error && (
        <div className="space-y-6 flex-grow">
          <div>
            <h3 className="text-lg font-semibold text-gray-300 mb-3">Persons Detected</h3>
            {detectedPersons.length > 0 ? (
              <ul className="space-y-2">
                {detectedPersons.map((p, i) => (
                  <li key={`person-${i}`} className="bg-gray-700/50 p-3 rounded-lg flex items-center">
                    <Icon name={p.gender || 'Person'} />
                    <span>{p.gender || 'Person'}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500 italic">No persons detected in the frame.</p>
            )}
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-300 mb-3">Objects Detected</h3>
            {detectedObjects.length > 0 ? (
              <ul className="space-y-2">
                {detectedObjects.map((obj, i) => (
                  <li key={`object-${i}`} className="bg-gray-700/50 p-3 rounded-lg flex items-center">
                    <Icon name="default" />
                    <span>{obj.label}</span>
                  </li>
                ))}
              </ul>
            ) : (
                <p className="text-gray-500 italic">No other objects detected.</p>
            )}
          </div>
        </div>
      )}
      
      <div className="mt-6 pt-4 border-t border-gray-700">
          {isDetecting ? (
             <p className="text-center text-teal-400 animate-pulse">Analyzing frame...</p>
          ) : (
             <p className="text-center text-gray-500">Waiting for next frame analysis.</p>
          )}
      </div>

    </div>
  );
};
