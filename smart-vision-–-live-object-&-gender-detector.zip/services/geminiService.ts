import { GoogleGenAI, Type } from "@google/genai";
import { Detection } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      label: {
        type: Type.STRING,
        description: 'The identified object or "Person".',
      },
      gender: {
        type: Type.STRING,
        description: 'If the label is "Person", classify the gender as "Male" or "Female". Otherwise, this can be omitted.',
      },
      box: {
        type: Type.OBJECT,
        properties: {
          x: { 
            type: Type.NUMBER,
            description: 'The top-left x-coordinate of the bounding box, normalized from 0 to 1.'
          },
          y: { 
            type: Type.NUMBER,
            description: 'The top-left y-coordinate of the bounding box, normalized from 0 to 1.'
          },
          width: { 
            type: Type.NUMBER,
            description: 'The width of the bounding box, normalized from 0 to 1.'
          },
          height: { 
            type: Type.NUMBER,
            description: 'The height of the bounding box, normalized from 0 to 1.'
          },
        },
        required: ['x', 'y', 'width', 'height'],
      },
    },
    required: ['label', 'box'],
  },
};

const systemInstruction = `You are an expert at analyzing images. Your task is to identify all prominent objects and people in the provided image.
- For each detected item, provide a descriptive label.
- If an item is a person, label it as "Person" and also classify their apparent gender as "Male" or "Female".
- For every item, provide a precise bounding box with coordinates normalized between 0 and 1.
- Respond ONLY with a valid JSON array matching the provided schema. Do not include any other text or markdown formatting.`;

export async function detectObjectsAndGender(base64Image: string): Promise<Detection[]> {
  try {
    const imagePart = {
      inlineData: {
        mimeType: 'image/jpeg',
        data: base64Image.split(',')[1],
      },
    };

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart] },
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema,
        temperature: 0.1,
      }
    });
    
    const jsonText = response.text.trim();
    const detections = JSON.parse(jsonText) as Detection[];
    
    // Validate the response structure
    if (!Array.isArray(detections)) {
        throw new Error("API response is not an array.");
    }

    return detections;

  } catch (error) {
    console.error('Error in Gemini API call:', error);
    throw new Error('Failed to process image with Gemini API.');
  }
}
